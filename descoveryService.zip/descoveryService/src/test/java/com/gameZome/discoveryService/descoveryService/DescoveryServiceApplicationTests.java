package com.gameZome.discoveryService.descoveryService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DescoveryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
